const fileInput = document.getElementById('videoFile');
const video = document.getElementById('video');
const placeholder = document.getElementById('placeholder');
const fileName = document.getElementById('fileName');
const captionText = document.getElementById('captionText');
const captionOverlay = document.getElementById('captionOverlay');
const stage = document.getElementById('stage');
const status = document.getElementById('status');
let currentUrl = null;

fileInput.addEventListener('change', () => {
  const file = fileInput.files && fileInput.files[0];
  if (!file) return;
  if (currentUrl) URL.revokeObjectURL(currentUrl);
  currentUrl = URL.createObjectURL(file);
  video.src = currentUrl;
  video.hidden = false;
  placeholder.hidden = true;
  fileName.textContent = file.name;
  status.textContent = 'Video loaded. Add caption text to preview it.';
});

captionText.addEventListener('input', () => {
  captionOverlay.textContent = captionText.value;
});

document.getElementById('aspect').addEventListener('change', (event) => {
  stage.classList.remove('landscape', 'portrait', 'square');
  stage.classList.add(event.target.value);
});

document.getElementById('clear').addEventListener('click', () => {
  captionText.value = '';
  captionOverlay.textContent = '';
  status.textContent = 'Caption cleared.';
});

function toSrtTime(seconds) {
  const ms = Math.floor((seconds % 1) * 1000);
  const whole = Math.floor(seconds);
  const h = String(Math.floor(whole / 3600)).padStart(2, '0');
  const m = String(Math.floor((whole % 3600) / 60)).padStart(2, '0');
  const s = String(whole % 60).padStart(2, '0');
  return `${h}:${m}:${s},${String(ms).padStart(3, '0')}`;
}

document.getElementById('downloadSrt').addEventListener('click', () => {
  const text = captionText.value.trim();
  if (!text) {
    status.textContent = 'Please type a caption first.';
    return;
  }
  const duration = Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 5;
  const end = Math.max(1, Math.min(duration, 5));
  const srt = `1\n${toSrtTime(0)} --> ${toSrtTime(end)}\n${text}\n`;
  const blob = new Blob([srt], {type: 'text/plain;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'clipmaster-captions.srt';
  a.click();
  URL.revokeObjectURL(url);
  status.textContent = 'Subtitle file downloaded.';
});
