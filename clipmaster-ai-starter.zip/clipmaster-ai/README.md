# ClipMaster AI — Starter

This is the first browser-based starter for ClipMaster AI.

## Run it
Open `index.html` in a modern browser, or publish the repository with GitHub Pages.

## Included now
- Local video selection and preview
- Caption text overlay preview
- Landscape, portrait (Shorts/Reels), and square preview layouts
- Download a basic `.srt` subtitle file

## Not included yet
- Automatic AI speech-to-text
- Real video rendering/export with captions burned in
- AI editing or cloud uploads

Those features need a processing backend and, for AI transcription, an AI service/API. Never put a private API key in browser JavaScript or commit it to GitHub.

## Publish with GitHub Pages
In your GitHub repository, open **Settings → Pages**. Under the build/deployment section choose **Deploy from a branch**, select **main** and **/(root)**, then save. GitHub will show the website address after deployment.
